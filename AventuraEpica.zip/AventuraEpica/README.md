## .vscode

Configurações do projeto.

## lib

Bibliotecas usadas no projeto.

## src

Contém os arquivos do projeto.